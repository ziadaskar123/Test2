# discord-kicker-bot
Kicker bot for Discord

### ENV VARS

`TOKEN` - OAuth2 token

`CHANNEL` - Text channel name to post to (Default: general)

`BOTUSERID` - Bot user id